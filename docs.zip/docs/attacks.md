# Poisoning Attacks

This repository supports poisoning-style attacks used to test robustness.

# Backdoor attack
A backdoor attack modifies a fraction of a malicious client's samples by:
- injecting a fixed feature-space trigger, and
- relabeling them to a chosen target label.

Relevant scripts (depending on your final implementation):
- `poison_backdoor.py`
- `backdoor_poisen_fixed.py`

#Label-flip attack
A label-flip attack changes labels of selected samples to corrupt training.

# Evaluation
Attack Success Rate (ASR) is computed by evaluating triggered inputs and measuring the fraction
classified into the target label. Use:
- `evaluate_asr.py`
