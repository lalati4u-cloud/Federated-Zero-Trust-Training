# Dataset

We use the CIC-IDS2017 intrusion detection dataset.

# Source
- CIC IDS 2017 (University of New Brunswick / Canadian Institute for Cybersecurity)
- Your paper cites the Zenodo record for the processed release (if used).

# Preprocessing
The script `prepare_cicids2017.py` handles dataset preparation, including typical steps such as:
- cleaning / filtering
- normalization / standardization
- label encoding

Your prepared dataset is then loaded by `cicids2017_prepared.py` (as applicable) and partitioned
for FL using `split_clients_dirichlet.py`.

## Expected Output
After preprocessing and splitting, the project should contain client partitions and server-side
validation/test sets used for evaluation (clean accuracy/Macro-F1 and ASR).
