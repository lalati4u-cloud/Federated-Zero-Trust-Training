# Experiments

## Main experiments (paper)
- FedAvg + backdoor poisoning
- FZTT + backdoor poisoning
- (Optional) label-flip poisoning
- Trust dynamics and client exclusion analysis

## How to run (module entrypoints)
FedAvg:
```bash
python3 -m fl.server_fedavg
```

FZTT:
```bash
python3 -m fl.server_fztt
```

## Key outputs
- Clean test accuracy
- Macro-F1
- Attack Success Rate (ASR)
- Trust score statistics per round (min/avg)
- Number of active/excluded clients per round

## Reproducibility
See the `configs/` folder for human-readable experiment configurations that match the paper.
