# Federated Zero-Trust Training (FZTT)

FZTT is a trust-aware aggregation strategy that integrates Zero-Trust principles into the FL lifecycle.

#Core idea
- No client is permanently trusted after admission.
- Each round, clients are evaluated and assigned a trust score **T ∈ [0,1]**.
- Clients below a threshold **θ** are excluded from aggregation.

# Trust update (paper-aligned)
Typical parameters in the paper:
- α: trust smoothing / decay factor
- β: penalty factor for suspicious behavior
- θ: acceptance threshold
- T_min: minimum trust floor

# Zero-Trust mapping (paper)
- Trust evaluation acts like a Policy Decision Point (PDP)
- Trust-aware aggregation acts like a Policy Enforcement Point (PEP)

FZTT therefore controls both:
1) who participates (authorization), and
2) how much influence they have (aggregation inclusion).
