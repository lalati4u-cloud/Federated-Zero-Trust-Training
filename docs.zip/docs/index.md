# FZTT Documentation

This repository provides the implementation of Federated Zero-Trust Training (FZTT),
a trust-aware aggregation framework for secure federated learning in adversarial IoT environments.

The project supports:
- Federated Learning with FedAvg and FZTT
- Backdoor and label-flip poisoning attacks
- Trust-based client filtering
- Evaluation using CIC-IDS2017

Start here:
- Installation ->�� `installation.md`
- Quickstart �-> `quickstart.md`
- Experiments ->�� `experiments.md`
