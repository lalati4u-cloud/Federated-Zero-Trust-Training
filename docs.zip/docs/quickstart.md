# Quickstart

This project is commonly run via the module entrypoints.

# 1) Prepare the dataset
```bash
python prepare_cicids2017.py
```

# 2) Split data into non-IID clients (Dirichlet)
```bash
python split_clients_dirichlet.py
```

# 3) Run FedAvg baseline
```bash
python3 -m fl.server_fedavg
```

# 4) Run FZTT
```bash
python3 -m fl.server_fztt
```

# 5) Evaluate Attack Success Rate (ASR)
```bash
python evaluate_asr.py
```
