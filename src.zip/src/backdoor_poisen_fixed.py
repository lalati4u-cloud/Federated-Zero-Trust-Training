import os
import json
import numpy as np
import torch
import shutil

# ----------------------------
# Config
# ----------------------------
BASE_DIR = "cicids2017_clients_20"

POISON_CLIENT_IDS = [1]          # poison client_001 (or e.g., [1, 10])
POISON_FRACTION = 0.2            # 20%

TRIGGER_FEATURE_IDXS = [0, 1, 2] # feature columns to perturb (0-based)
TRIGGER_DELTA = 6.0              # additive shift in standardized space

TARGET_LABEL_ID = 11             # your chosen target label
SEED = 42

ONLY_POISON_NON_TARGET = True

# If True: restore train.pt from train_clean.pt before poisoning (recommended)
RESTORE_CLEAN_BEFORE_POISON = True

# ----------------------------
rng = np.random.default_rng(SEED)

def load_pt(path: str):
    d = torch.load(path)
    return d["X"], d["y"]

def save_pt(path: str, X: torch.Tensor, y: torch.Tensor):
    torch.save({"X": X, "y": y}, path)

def poison_client_train(client_dir: str):
    train_path = os.path.join(client_dir, "train.pt")
    if not os.path.exists(train_path):
        raise FileNotFoundError(f"Missing {train_path}")

    backup_path = os.path.join(client_dir, "train_clean.pt")

    # Backup original once
    if not os.path.exists(backup_path):
        X0, y0 = load_pt(train_path)
        save_pt(backup_path, X0.clone(), y0.clone())

    # Optionally restore from clean before re-poisoning
    if RESTORE_CLEAN_BEFORE_POISON:
        shutil.copy2(backup_path, train_path)

    X, y = load_pt(train_path)
    X = X.clone()
    y = y.clone()

    n = int(X.shape[0])

    # candidates to poison
    if ONLY_POISON_NON_TARGET:
        candidates = torch.where(y != TARGET_LABEL_ID)[0].cpu().numpy()
    else:
        candidates = np.arange(n)

    if len(candidates) == 0:
        return {"n_train": n, "poisoned": 0, "note": "No candidates to poison."}

    k = int(np.floor(POISON_FRACTION * n))
    k = min(k, len(candidates))
    if k <= 0:
        return {"n_train": n, "poisoned": 0, "note": "POISON_FRACTION too small."}

    poisoned_idx = rng.choice(candidates, size=k, replace=False)

    # ---- FIXED trigger application ----
    # Use one advanced indexing operation so the write hits X
    row_idx = torch.tensor(poisoned_idx, dtype=torch.long)
    col_idx = torch.tensor(TRIGGER_FEATURE_IDXS, dtype=torch.long)

    # broadcast to (k, num_trigger_features)
    X[row_idx[:, None], col_idx[None, :]] += TRIGGER_DELTA

    # force labels to target
    y[row_idx] = TARGET_LABEL_ID

    save_pt(train_path, X, y)

    return {
        "n_train": n,
        "poisoned": int(k),
        "poison_fraction_effective": float(k / n),
        "trigger_feature_idxs": TRIGGER_FEATURE_IDXS,
        "trigger_delta": TRIGGER_DELTA,
        "target_label_id": int(TARGET_LABEL_ID),
        "only_poison_non_target": bool(ONLY_POISON_NON_TARGET),
        "restored_clean_before_poison": bool(RESTORE_CLEAN_BEFORE_POISON),
    }

def main():
    poison_report = {
        "base_dir": BASE_DIR,
        "poison_client_ids": POISON_CLIENT_IDS,
        "poison_fraction": POISON_FRACTION,
        "trigger_feature_idxs": TRIGGER_FEATURE_IDXS,
        "trigger_delta": TRIGGER_DELTA,
        "target_label_id": int(TARGET_LABEL_ID),
        "seed": SEED,
        "only_poison_non_target": ONLY_POISON_NON_TARGET,
        "restored_clean_before_poison": RESTORE_CLEAN_BEFORE_POISON,
        "clients": []
    }

    for cid in POISON_CLIENT_IDS:
        cdir = os.path.join(BASE_DIR, f"client_{cid:03d}")
        if not os.path.isdir(cdir):
            raise FileNotFoundError(f"Client directory not found: {cdir}")

        info = poison_client_train(cdir)
        info["client_id"] = int(cid)
        poison_report["clients"].append(info)

        print(f"[INFO] Poisoned client_{cid:03d}: {info.get('poisoned', 0)} samples out of {info.get('n_train', 0)}")

    out_json = os.path.join(BASE_DIR, "poison_config.json")
    with open(out_json, "w") as f:
        json.dump(poison_report, f, indent=2)

    print("[DONE] Backdoor poisoning complete (FIXED).")
    print("Saved config:", out_json)

if __name__ == "__main__":
    main()
