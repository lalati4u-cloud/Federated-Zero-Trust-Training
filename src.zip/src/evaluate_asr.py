import torch
import torch.nn as nn
import numpy as np
from sklearn.metrics import accuracy_score, f1_score

# ----------------------------
# Config
# ----------------------------
MODEL_PATH = "global_model_poisoned.pt"
CLEAN_TEST_PATH = "cicids2017_clients_20/global_test.pt"
TRIG_TEST_PATH  = "cicids2017_clients_20/global_test_triggered.pt"
TARGET = 11
BATCH_SIZE = 4096

# ----------------------------
# Model (must match training)
# ----------------------------
model = nn.Sequential(
    nn.Linear(78, 128),
    nn.ReLU(),
    nn.Linear(128, 16)
)
model.load_state_dict(torch.load(MODEL_PATH, map_location="cpu"))
model.eval()

def predict_in_batches(X: torch.Tensor) -> np.ndarray:
    preds = []
    with torch.no_grad():
        for i in range(0, X.shape[0], BATCH_SIZE):
            xb = X[i:i+BATCH_SIZE]
            pb = torch.argmax(model(xb), dim=1).cpu().numpy()
            preds.append(pb)
    return np.concatenate(preds)

# ----------------------------
# Clean evaluation
# ----------------------------
clean = torch.load(CLEAN_TEST_PATH)
X_clean, y_clean = clean["X"], clean["y"].cpu().numpy()

pred_clean = predict_in_batches(X_clean)
acc = accuracy_score(y_clean, pred_clean)
f1  = f1_score(y_clean, pred_clean, average="macro")

print("Clean Test Accuracy:", acc)
print("Clean Test Macro-F1:", f1)

# ----------------------------
# Backdoor ASR evaluation
# ----------------------------
trig = torch.load(TRIG_TEST_PATH)
X_trig = trig["X"]

pred_trig = predict_in_batches(X_trig)
asr = np.mean(pred_trig == TARGET)

print("ASR (Backdoor Success Rate):", asr)
