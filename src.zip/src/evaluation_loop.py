import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import f1_score, accuracy_score
import numpy as np

device = "cuda" if torch.cuda.is_available() else "cpu"

train = torch.load("cicids2017_prepared/train.pt")
val   = torch.load("cicids2017_prepared/val.pt")

train_loader = DataLoader(TensorDataset(train["X"], train["y"]), batch_size=2048, shuffle=True)
val_loader   = DataLoader(TensorDataset(val["X"], val["y"]), batch_size=2048)

model = nn.Sequential(
    nn.Linear(78, 128),
    nn.ReLU(),
    nn.Linear(128, 16)
).to(device)

criterion = nn.CrossEntropyLoss()
opt = torch.optim.Adam(model.parameters(), lr=1e-3)

def evaluate(loader):
    model.eval()
    ys, ps = [], []
    with torch.no_grad():
        for X, y in loader:
            X, y = X.to(device), y.to(device)
            logits = model(X)
            pred = torch.argmax(logits, dim=1)
            ys.append(y.cpu().numpy())
            ps.append(pred.cpu().numpy())
    y_true = np.concatenate(ys)
    y_pred = np.concatenate(ps)
    return accuracy_score(y_true, y_pred), f1_score(y_true, y_pred, average="macro")

# train 1 epoch
model.train()
for X, y in train_loader:
    X, y = X.to(device), y.to(device)
    opt.zero_grad()
    loss = criterion(model(X), y)
    loss.backward()
    opt.step()

acc, f1 = evaluate(val_loader)
print("Val accuracy:", acc, "Val macro-F1:", f1)
