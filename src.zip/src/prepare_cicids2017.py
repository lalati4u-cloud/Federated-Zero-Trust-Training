import os
import json
import numpy as np
import torch

# ------------------------------------------------------------
# Split train.pt into 20 NON-IID clients (label-skew via Dirichlet)
# Keeps global val/test unchanged.
# ------------------------------------------------------------

IN_DIR = "cicids2017_prepared"
OUT_DIR = "cicids2017_clients_20"
N_CLIENTS = 20
SEED = 42

# Non-IID strength: smaller alpha => more non-IID (more label-skew)
DIRICHLET_ALPHA = 0.3

# Optional: ensure each client has at least this many samples (best effort)
MIN_SAMPLES_PER_CLIENT = 2000

# Optional: also create per-client local validation split from each client's data
MAKE_CLIENT_VAL = True
CLIENT_VAL_FRAC = 0.1  # 10% of each client's data

# ------------------------------------------------------------

rng = np.random.default_rng(SEED)

def dirichlet_split_indices(y: np.ndarray, n_clients: int, alpha: float, seed: int):
    """Return list of indices for each client using Dirichlet label-skew split."""
    rng_local = np.random.default_rng(seed)
    classes = np.unique(y)
    client_indices = [[] for _ in range(n_clients)]

    for c in classes:
        idx_c = np.where(y == c)[0]
        rng_local.shuffle(idx_c)

        # sample proportions for this class across clients
        props = rng_local.dirichlet(alpha=np.full(n_clients, alpha))
        # convert to counts
        counts = (props * len(idx_c)).astype(int)

        # fix rounding so counts sum exactly
        diff = len(idx_c) - counts.sum()
        if diff > 0:
            for i in rng_local.choice(n_clients, size=diff, replace=True):
                counts[i] += 1
        elif diff < 0:
            for i in rng_local.choice(np.where(counts > 0)[0], size=abs(diff), replace=True):
                counts[i] -= 1

        start = 0
        for i in range(n_clients):
            take = counts[i]
            if take > 0:
                client_indices[i].extend(idx_c[start:start + take].tolist())
            start += take

    # shuffle within each client
    for i in range(n_clients):
        rng_local.shuffle(client_indices[i])

    return [np.array(ci, dtype=np.int64) for ci in client_indices]


def enforce_min_samples(client_indices, y, min_samples, seed):
    """Best-effort: move samples from large clients to small ones to reach min_samples."""
    rng_local = np.random.default_rng(seed)
    sizes = np.array([len(ci) for ci in client_indices])
    if sizes.min() >= min_samples:
        return client_indices

    # pool from donors (largest first)
    while sizes.min() < min_samples:
        receiver = int(np.argmin(sizes))
        donor = int(np.argmax(sizes))
        if sizes[donor] <= min_samples:
            break

        # move a small batch
        move_k = min(min_samples - sizes[receiver], max(1, sizes[donor] - min_samples))
        donor_idx = client_indices[donor]
        take = donor_idx[:move_k]
        client_indices[donor] = donor_idx[move_k:]
        client_indices[receiver] = np.concatenate([client_indices[receiver], take])

        sizes = np.array([len(ci) for ci in client_indices])

    # shuffle again
    for i in range(len(client_indices)):
        rng_local.shuffle(client_indices[i])
    return client_indices


def save_pt(path, X, y):
    torch.save({"X": X, "y": y}, path)


def main():
    os.makedirs(OUT_DIR, exist_ok=True)

    # Load global splits
    train = torch.load(os.path.join(IN_DIR, "train.pt"))
    val   = torch.load(os.path.join(IN_DIR, "val.pt"))
    test  = torch.load(os.path.join(IN_DIR, "test.pt"))

    X_train = train["X"]
    y_train = train["y"].cpu().numpy()  # for splitting logic

    # Save global eval sets
    save_pt(os.path.join(OUT_DIR, "global_val.pt"), val["X"], val["y"])
    save_pt(os.path.join(OUT_DIR, "global_test.pt"), test["X"], test["y"])

    # Non-IID split
    client_indices = dirichlet_split_indices(y_train, N_CLIENTS, DIRICHLET_ALPHA, SEED)
    client_indices = enforce_min_samples(client_indices, y_train, MIN_SAMPLES_PER_CLIENT, SEED)

    # Create clients
    summary = {
        "n_clients": N_CLIENTS,
        "dirichlet_alpha": DIRICHLET_ALPHA,
        "min_samples_per_client": MIN_SAMPLES_PER_CLIENT,
        "make_client_val": MAKE_CLIENT_VAL,
        "client_val_frac": CLIENT_VAL_FRAC if MAKE_CLIENT_VAL else None,
        "clients": []
    }

    for cid in range(N_CLIENTS):
        cdir = os.path.join(OUT_DIR, f"client_{cid:03d}")
        os.makedirs(cdir, exist_ok=True)

        idx = client_indices[cid]
        Xc = X_train[idx]
        yc = train["y"][idx]

        # optional per-client val
        if MAKE_CLIENT_VAL and len(idx) > 10:
            n_val = int(len(idx) * CLIENT_VAL_FRAC)
            perm = rng.permutation(len(idx))
            val_idx_local = perm[:n_val]
            trn_idx_local = perm[n_val:]

            Xc_tr = Xc[trn_idx_local]
            yc_tr = yc[trn_idx_local]
            Xc_va = Xc[val_idx_local]
            yc_va = yc[val_idx_local]

            save_pt(os.path.join(cdir, "train.pt"), Xc_tr, yc_tr)
            save_pt(os.path.join(cdir, "val.pt"),   Xc_va, yc_va)
        else:
            save_pt(os.path.join(cdir, "train.pt"), Xc, yc)

        # stats
        y_np = yc.cpu().numpy()
        unique, counts = np.unique(y_np, return_counts=True)
        dist = {int(k): int(v) for k, v in zip(unique, counts)}

        summary["clients"].append({
            "client_id": cid,
            "n_samples_total": int(len(y_np)),
            "label_distribution": dist
        })

        print(f"[INFO] client_{cid:03d}: {len(y_np):,} samples, {len(dist)} labels")

    # Save summary
    with open(os.path.join(OUT_DIR, "split_summary.json"), "w") as f:
        json.dump(summary, f, indent=2)

    print("\n[DONE] Created 20 clients in:", OUT_DIR)
    print("Saved: global_val.pt, global_test.pt, per-client train/val, split_summary.json")


if __name__ == "__main__":
    main()
