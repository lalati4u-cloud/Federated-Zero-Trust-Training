"""
Dirichlet-based non-IID client splitter for CIC-IDS2017

This script partitions the preprocessed dataset into non-IID client subsets
using a Dirichlet label-skew distribution.

Author: Laila Al-Terkawi
"""

import os
import json
import numpy as np
import torch

# ----------------------------
# Config
# ----------------------------
INPUT_DIR = "cicids2017_prepared"
OUTPUT_DIR = "cicids2017_clients_20"
NUM_CLIENTS = 20
DIRICHLET_ALPHA = 0.3
SEED = 42

# ----------------------------

rng = np.random.default_rng(SEED)

def load_pt(path):
    d = torch.load(path)
    return d["X"], d["y"]

def save_pt(path, X, y):
    torch.save({"X": X, "y": y}, path)

def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    X, y = load_pt(os.path.join(INPUT_DIR, "train.pt"))
    num_classes = len(torch.unique(y))

    client_indices = [[] for _ in range(NUM_CLIENTS)]

    for c in range(num_classes):
        class_idx = torch.where(y == c)[0].numpy()
        rng.shuffle(class_idx)

        proportions = rng.dirichlet([DIRICHLET_ALPHA] * NUM_CLIENTS)
        proportions = (np.cumsum(proportions) * len(class_idx)).astype(int)[:-1]

        splits = np.split(class_idx, proportions)

        for i, split in enumerate(splits):
            client_indices[i].extend(split.tolist())

    summary = {}

    for i in range(NUM_CLIENTS):
        idx = np.array(client_indices[i])
        Xc, yc = X[idx], y[idx]

        cdir = os.path.join(OUTPUT_DIR, f"client_{i:03d}")
        os.makedirs(cdir, exist_ok=True)

        save_pt(os.path.join(cdir, "train.pt"), Xc, yc)

        summary[f"client_{i:03d}"] = {
            "samples": len(yc),
            "unique_labels": int(len(torch.unique(yc)))
        }

        print(f"[INFO] client_{i:03d}: {len(yc)} samples")

    with open(os.path.join(OUTPUT_DIR, "split_summary.json"), "w") as f:
        json.dump(summary, f, indent=2)

    print("[DONE] Dirichlet client split completed.")

if __name__ == "__main__":
    main()

