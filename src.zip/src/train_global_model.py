import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
from sklearn.metrics import accuracy_score, f1_score

# ----------------------------
# Load training + validation data
# ----------------------------
train = torch.load("cicids2017_prepared/train.pt")
val   = torch.load("cicids2017_prepared/val.pt")

train_loader = DataLoader(
    TensorDataset(train["X"], train["y"]),
    batch_size=2048,
    shuffle=True
)

val_loader = DataLoader(
    TensorDataset(val["X"], val["y"]),
    batch_size=2048,
    shuffle=False
)

# ----------------------------
# Define model
# ----------------------------
model = nn.Sequential(
    nn.Linear(78, 128),
    nn.ReLU(),
    nn.Linear(128, 16)
)

criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

# ----------------------------
# Train
# ----------------------------
EPOCHS = 3

for epoch in range(EPOCHS):
    model.train()
    for X, y in train_loader:
        optimizer.zero_grad()
        out = model(X)
        loss = criterion(out, y)
        loss.backward()
        optimizer.step()

    # ----------------------------
    # Validation (fixed)
    # ----------------------------
    model.eval()
    ys, ps = [], []
    with torch.no_grad():
        for X, y in val_loader:
            logits = model(X)
            pred = torch.argmax(logits, dim=1)

            ys.append(y.cpu().numpy())
            ps.append(pred.cpu().numpy())

    y_true = np.concatenate(ys)
    y_pred = np.concatenate(ps)

    acc = accuracy_score(y_true, y_pred)
    f1  = f1_score(y_true, y_pred, average="macro")

    print(f"Epoch {epoch+1}: Val Accuracy={acc:.4f}, Macro-F1={f1:.4f}")

# ----------------------------
# Save trained model
# ----------------------------
torch.save(model.state_dict(), "global_model.pt")
print("Saved global_model.pt")
