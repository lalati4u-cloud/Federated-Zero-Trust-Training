import os
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
from sklearn.metrics import accuracy_score, f1_score

BASE_DIR = "cicids2017_clients_20"
N_CLIENTS = 20
BATCH_SIZE = 2048
EPOCHS = 3
LR = 1e-3

# ----------------------------
# Load and combine all client TRAIN sets (poisoned ones included)
# ----------------------------
Xs, ys = [], []
total = 0

for cid in range(N_CLIENTS):
    path = os.path.join(BASE_DIR, f"client_{cid:03d}", "train.pt")
    d = torch.load(path)
    Xs.append(d["X"])
    ys.append(d["y"])
    total += d["X"].shape[0]
    print(f"[INFO] loaded client_{cid:03d} train: {d['X'].shape}")

X_train = torch.cat(Xs, dim=0)
y_train = torch.cat(ys, dim=0)
print("[INFO] combined train:", X_train.shape, y_train.shape, "total=", total)

# Use global_val for validation (clean)
val = torch.load(os.path.join(BASE_DIR, "global_val.pt"))
X_val, y_val = val["X"], val["y"]

train_loader = DataLoader(TensorDataset(X_train, y_train), batch_size=BATCH_SIZE, shuffle=True)
val_loader   = DataLoader(TensorDataset(X_val, y_val), batch_size=BATCH_SIZE, shuffle=False)

# ----------------------------
# Model (same as before)
# ----------------------------
model = nn.Sequential(
    nn.Linear(78, 128),
    nn.ReLU(),
    nn.Linear(128, 16)
)

criterion = nn.CrossEntropyLoss()
opt = torch.optim.Adam(model.parameters(), lr=LR)

def eval_loader(loader):
    model.eval()
    ys_, ps_ = [], []
    with torch.no_grad():
        for X, y in loader:
            pred = torch.argmax(model(X), dim=1)
            ys_.append(y.cpu().numpy())
            ps_.append(pred.cpu().numpy())
    y_true = np.concatenate(ys_)
    y_pred = np.concatenate(ps_)
    return accuracy_score(y_true, y_pred), f1_score(y_true, y_pred, average="macro")

# ----------------------------
# Train
# ----------------------------
for ep in range(EPOCHS):
    model.train()
    for X, y in train_loader:
        opt.zero_grad()
        loss = criterion(model(X), y)
        loss.backward()
        opt.step()

    acc, f1 = eval_loader(val_loader)
    print(f"Epoch {ep+1}: Val Accuracy={acc:.4f}, Macro-F1={f1:.4f}")

torch.save(model.state_dict(), "global_model_poisoned.pt")
print("[DONE] Saved global_model_poisoned.pt")
